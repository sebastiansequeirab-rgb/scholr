```markdown
# Design System: Refined Clarity

## 1. Overview & Creative North Star: "The Digital Sanctuary"
This design system is built to transform the chaotic academic experience into a focused, premium ritual. The Creative North Star is **The Digital Sanctuary**—a space that feels less like a utility tool and more like a high-end, physical studio.

To move beyond the "template" look, we abandon rigid, boxy layouts in favor of **Tonal Architecture**. We break the standard grid by using intentional asymmetry—letting typography drive the layout and using whitespace as a structural element. Elements should feel like they are floating in a vacuum of deep space, governed by physics, light, and soft edges.

---

## 2. Color & Surface Philosophy
Our palette is rooted in deep obsidian tones, punctuated by crystalline accents. We do not use color to decorate; we use it to direct focus.

### The Palette
*   **Base & Neutral:** `surface_container_lowest` (#0B0E14) is our bedrock.
*   **Primary Accent:** `primary` (#ADC6FF) for core actions, inspired by the clarity of iOS Blue.
*   **Intelligence Accent:** `tertiary` (#E9B3FF) reserved exclusively for AI-driven insights and features.
*   **Muted Categories:** Use Sage, Dusty Rose, and Pale Blue at 10-15% opacity for low-vibrancy categorization that doesn't break the dark mode immersion.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders to section off major areas of the UI. Separation must be achieved through **Background Shifts**.
*   *Example:* A sidebar should be `surface_container_low`, the main editor `surface_dim`, and an inspector panel `surface_container`. The eye perceives the boundary through the change in value, not a line.

### The "Glass & Gradient" Rule
Standard flat surfaces feel "cheap." To achieve a premium feel:
*   **Glassmorphism:** Floating modals and navigation bars must use `surface_container` at 70% opacity with a `20px` backdrop blur.
*   **Signature Textures:** Main Call-to-Actions (CTAs) should utilize a subtle linear gradient from `primary` to `primary_container` at a 135° angle. This adds "soul" and a sense of tactile depth.

---

## 3. Typography: Editorial Authority
We use a high-contrast scale to create an editorial feel. Typography is our primary UI element.

*   **Display & Headlines:** Use **Inter** (as a proxy for SF Pro Display). Headlines should have tight tracking (-0.02em) to feel "locked in" and authoritative.
*   **Data & Meta:** Use **SF Mono** for dates, word counts, and code snippets. This provides a "technical" contrast to the organic feel of the headings.
*   **Hierarchy as Identity:** 
    *   `display-lg` is for moments of achievement (e.g., "Semester Complete").
    *   `title-md` is for standard navigation.
    *   `label-sm` in SF Mono is for secondary metadata, always in `on_surface_variant`.

---

## 4. Elevation & Depth: Tonal Layering
In this design system, height is expressed through light and transparency, not shadows.

*   **The Layering Principle:** Treat the UI as stacked sheets of obsidian glass.
    *   Level 0 (Backdrop): `surface_dim`
    *   Level 1 (Cards/Content): `surface_container_low`
    *   Level 2 (Popovers/Active Elements): `surface_container_high`
*   **Ambient Shadows:** If an element must float (like a context menu), use a "Shadow Tint." Instead of black, the shadow is `surface_container_highest` with a 40px blur at 40% opacity. It should feel like a soft glow rather than a dark stain.
*   **The Ghost Border:** For high-density data where separation is critical, use a `1px` stroke of `outline_variant` at **10% opacity**. It should be barely visible—a "whisper" of a boundary.

---

## 5. Components

### Buttons & Inputs
*   **Primary Button:** Uses the `lg` (2rem/32px) corner radius. Height should be a generous 48px to feel "touchable."
*   **Input Fields:** `surface_container_lowest` backgrounds with a `1px` Ghost Border. On focus, the border transitions to a 100% opaque `primary` stroke with a subtle outer glow.

### Cards & Lists
*   **No Dividers:** Lists must never use horizontal lines. Use `16px` of vertical whitespace to separate items. 
*   **Icon Containers:** Icons should be housed in `24px` rounded squares with a 10% opacity background of the icon's color (e.g., a blue icon sits on a 10% blue square).

### AI Interaction (Soft Violet)
*   **The AI Glow:** Any element powered by Scholr's intelligence should feature a `2px` inner-glow of `tertiary_container`. 
*   **The "Violet Pulse":** Use a subtle, slow-breathing opacity animation (from 0.4 to 0.8) for AI loading states.

### Chips & Categories
*   **Selection Chips:** Use `md` (1.5rem) rounding. Unselected chips are transparent with a Ghost Border; selected chips take on the muted pastel category color with `on_surface` text.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use extreme corner rounding (24px) for all main containers to evoke a friendly, modern feel.
*   **Do** prioritize "Breathing Room." If you think there is enough padding, add 8px more.
*   **Do** use SF Mono for "functional" data to give the student a sense of precision.

### Don't
*   **Don't** use pure black (#000000). Always use the `surface_container_lowest` (#0B0E14) to maintain depth.
*   **Don't** use 100% opaque borders. They create "visual noise" and break the sanctuary feel.
*   **Don't** use standard "drop shadows." If it doesn't feel like light passing through glass, it doesn't belong.
*   **Don't** clutter. If a feature isn't essential to the current task, hide it in a `surface_container_high` overflow menu.